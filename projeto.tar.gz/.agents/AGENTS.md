# Workspace Rules

## Response Style
- Always include a brief summary of context/intent before executing actions or tool calls (explaining directly what will be investigated, read, or modified).
